var searchData=
[
  ['whitespacesmanager_0',['WhitespacesManager',['../classanalizadorlexico_1_1WhitespacesManager.html',1,'analizadorlexico']]]
];
