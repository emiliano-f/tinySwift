var searchData=
[
  ['charconsumption_0',['charConsumption',['../classanalizadorlexico_1_1LiteralsManager.html#a8835a525cc708db83eecdd17e10269ad',1,'analizadorlexico::LiteralsManager']]],
  ['commentsmanager_1',['CommentsManager',['../classanalizadorlexico_1_1CommentsManager.html#a71c346e9c4c9a9468e9f2c7755c28333',1,'analizadorlexico::CommentsManager']]],
  ['consumption_2',['consumption',['../classanalizadorlexico_1_1WhitespacesManager.html#a21e382e9137dbf6977c6db9533cc3d42',1,'analizadorlexico::WhitespacesManager']]]
];
