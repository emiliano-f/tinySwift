var searchData=
[
  ['deletecommentblock_0',['deleteCommentBlock',['../classanalizadorlexico_1_1CommentsManager.html#a9a6c6d4c57ee968f338b9119fbfb7b7b',1,'analizadorlexico::CommentsManager']]],
  ['description_1',['description',['../classanalizadorlexico_1_1IllegalTokenException.html#a1c3fcf66a8cf82ab70ee26c6ae126aae',1,'analizadorlexico::IllegalTokenException']]]
];
