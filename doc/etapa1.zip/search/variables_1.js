var searchData=
[
  ['description_0',['description',['../classanalizadorlexico_1_1IllegalTokenException.html#a1c3fcf66a8cf82ab70ee26c6ae126aae',1,'analizadorlexico::IllegalTokenException']]]
];
