var searchData=
[
  ['description_0',['description',['../classanalizadorsintactico_1_1SyntacticErrorException.html#a18a2631fb3e5f9afa9a968bb9d980656',1,'analizadorsintactico::SyntacticErrorException']]]
];
