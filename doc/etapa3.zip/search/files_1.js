var searchData=
[
  ['classstruct_2ejava_0',['ClassStruct.java',['../ClassStruct_8java.html',1,'']]],
  ['commentsmanager_2ejava_1',['CommentsManager.java',['../CommentsManager_8java.html',1,'']]]
];
