var searchData=
[
  ['description_0',['description',['../classanalizadorlexico_1_1IllegalTokenException.html#a1c3fcf66a8cf82ab70ee26c6ae126aae',1,'analizadorlexico.IllegalTokenException.description()'],['../classanalizadorsemantico_1_1IncompleteSymbolTableException.html#a2e962915bba885f41f766d61a967c301',1,'analizadorsemantico.IncompleteSymbolTableException.description()'],['../classanalizadorsintactico_1_1SyntacticErrorException.html#a18a2631fb3e5f9afa9a968bb9d980656',1,'analizadorsintactico.SyntacticErrorException.description()']]]
];
