var searchData=
[
  ['whitespacesmanager_0',['WhitespacesManager',['../classanalizadorlexico_1_1WhitespacesManager.html',1,'analizadorlexico.WhitespacesManager'],['../classanalizadorlexico_1_1WhitespacesManager.html#a894f9fe6e8fe0911be732c2ee9d7c004',1,'analizadorlexico.WhitespacesManager.WhitespacesManager()']]],
  ['whitespacesmanager_2ejava_1',['WhitespacesManager.java',['../WhitespacesManager_8java.html',1,'']]]
];
