var searchData=
[
  ['whitespacesmanager_2ejava_0',['WhitespacesManager.java',['../WhitespacesManager_8java.html',1,'']]]
];
